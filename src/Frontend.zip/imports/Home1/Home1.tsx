import { useState, useEffect, useRef, memo, useCallback, type RefObject } from "react";
import { useNavigate } from "react-router-dom";
import { useTransition, type SharedRect } from "../../app/context/TransitionContext";
import svgPaths from "./svg-n029qayjm7";
import socialSvgPaths from "../svg-ejvbwqgg01";
import JournalHeader from "../../app/components/layout/JournalHeader";
import { useReveal } from "../../app/hooks/useReveal";

// ── Static assets (never change) ─────────────────────────────────────────────
import imgEntireWebsite    from "../../assets/0dd65294414a90d32335209969f40ac5042eb287.webp";
import imgFrame2106258500  from "../../assets/86bf7c0a9e2c9ce1971e67dfc02e8d7713a8c5f3.webp";
import imgFrame2106258502  from "../../assets/e7d8029b679abc3818d7b0073eb12f469c5282c0.webp";
import imgFrame2106258503  from "../../assets/78998cedd18b8246f027b5575f3ff5264b04c564.webp";
import imgImage48          from "../../assets/d0553f6129a7fac1b174ec3e794d941d51287eea.webp";
import imgFrame2106258466  from "../../assets/3c69fed734b46e09bcbca5fd64d204e588c1d31e.webp";
import imgComponent21      from "../../assets/51db19e7ba1176f759ee55b5c3fc2f8561581637.webp";
import imgPrimaryLogos     from "../../assets/lockup3.png";
import imgComponent22      from "../../assets/ef5789f32fa9b15364e39033c5d7cb0a9747ec22.webp";
import imgRectangle30      from "../../assets/23497d1b739628a6a7bb08b118680a57cca44246.webp";
import imgServicesSection  from "../../assets/79ba139c3a44f7977c3a8ad1f6ade8cf14fbb105.webp";
import imgFrame2106258506  from "../../assets/75226685f4f76f704b886f96c7d3f66fad2ea681.webp";
import imgPrimaryLogos1    from "../../assets/locckup7.png";
import imgContactPage      from "../../assets/afae93e180d21f30c2ae138886efb63bc064a5e6.webp";
import imgPrimaryLogos2    from "../../assets/4e454c35d52b905142f0f45a93315e3a6c51ea01.webp";

// ── Project data ──────────────────────────────────────────────────────────────
import { HOME_PROJECTS, CYCLE_MS, FADE_MS } from "../../data/homeProjects";
import type { HomeProject } from "../../data/homeProjects";

// ─────────────────────────────────────────────────────────────────────────────
// STATIC SECTIONS  (unchanged from original)
// ─────────────────────────────────────────────────────────────────────────────

function Frame7() {
  return (
    <div className="h-[306px] relative shrink-0 w-[224px]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img decoding="async" alt="" className="absolute h-full left-[-34.64%] max-w-none top-0 w-[156.95%]" src={imgFrame2106258500} />
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="h-[441px] relative shrink-0 w-[254px]">
      <img decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgFrame2106258502} />
    </div>
  );
}

function Frame9() {
  return (
    <div className="h-[375px] relative shrink-0 w-[280px]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img decoding="async" alt="" className="absolute h-full left-[-46.74%] max-w-none top-0 w-[236.34%]" src={imgFrame2106258503} />
      </div>
    </div>
  );
}

function Frame43() {
  return (
    <div
      className="absolute content-stretch flex gap-[20px] items-end left-[33px] top-[281px]"
      data-anim="intro"
      data-anim-variant="zoom"
      data-anim-order="1"
    >
      <Frame7 />
      <Frame8 />
      <Frame9 />
    </div>
  );
}

function EntireWebsite() {
  return (
    <div className="absolute h-[770px] left-0 overflow-clip top-0 w-full" data-name="Entire Website">
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <div className="absolute bg-[rgba(254,244,219,0.95)] inset-0" />
        <img decoding="async" alt="" className="absolute max-w-none object-cover size-full" src={imgEntireWebsite} />
      </div>
      <JournalHeader activePage="Home" />
      <Frame43 />
      <p
        data-anim="intro"
        data-anim-variant="text"
        data-anim-order="3"
        data-anim-blur="6"
        className="-translate-x-full [word-break:break-word] absolute capitalize font-['IBM_Plex_Serif',serif] h-[66px] leading-[0] left-[calc(59.50%+579px)] not-italic text-[#553319] text-[0px] text-right top-[566px] tracking-[-0.88px] w-[558px]">
        <span className="font-['IBM_Plex_Serif',serif] leading-[1.2] text-[22px] font font-semibold">A Boutique interior design studio</span>
        <span className="leading-[1.2] text-[22px]">{` creating spaces`}</span>
        <span className="leading-[1.2] text-[22px]">{` `}</span>
        <span className="leading-[1.2] text-[22px]">that are rooted, intentional, and designed for you.</span>
      </p>
      <p
        data-anim="intro"
        data-anim-variant="text"
        data-anim-order="4"
        data-anim-blur="10"
        className="-translate-x-1/2 [word-break:break-word] absolute capitalize font-['Instrument_Serif'] italic leading-[1.2] left-[calc(59.50%+317px)] text-[#703000] text-[96px] text-center top-[632px] tracking-[-3.84px] w-[524px]">Studio Inside eye</p>
      <div
        data-anim="intro"
        data-anim-variant="fade"
        data-anim-order="0"
        className="absolute h-[319px] left-[calc(58.33%+82px)] top-[-63px] w-[237px]" data-name="image 48">
        <div data-anim="parallax" data-parallax-speed="0.05" className="absolute inset-0">
          <img decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage48} />
        </div>
      </div>
      <div
        data-anim="intro"
        data-anim-variant="fade"
        data-anim-order="2"
        className="absolute h-[365px] left-[calc(75%-14px)] top-[-6px] w-[272px]" data-name="image 49">
        <div data-anim="parallax" data-parallax-speed="0.085" className="absolute inset-0">
          <img decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage48} />
        </div>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[33px] left-[calc(54.17%+41.5px)] rounded-[8px] top-[calc(50%+145px)] w-[71px]">
      <img loading="lazy" decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[8px] size-full" src={imgFrame2106258466} />
    </div>
  );
}

function Group() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute contents left-[calc(50%+1px)] top-[calc(50%+1.5px)]">
      <div
        data-anim="reveal"
        data-anim-variant="text"
        data-anim-blur="6"
        data-anim-delay="0.05"
        className="-translate-x-1/2 [word-break:break-word] absolute font-['Instrument_Serif',sans-serif] leading-[0] left-[calc(50%-0.5px)] not-italic text-[#5d5e36] text-[40px] text-center top-[calc(50%+67.5px)] tracking-[-1px] w-[683px] whitespace-pre-wrap">
        <p className="leading-[normal] mb-0">At Studio Inside Eye, every space starts with you.</p>
        <p className="leading-[normal]">{`We design around how you live,              what you need, what you value.`}</p>
      </div>
      <p
        data-anim="reveal"
        data-anim-variant="text"
        data-anim-blur="6"
        className="-translate-x-1/2 [word-break:break-word] absolute font-['Instrument_Serif',sans-serif] leading-[normal] left-[calc(50%+2.5px)] not-italic text-[#5d5e36] text-[40px] text-center top-[calc(50%-220.5px)] tracking-[-1px] w-[683px]">
        Designing timeless residential interiors for modern
        <br aria-hidden />
        California, across San Jose and the Bay Area.
      </p>
      <Frame4 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[33px] left-[calc(37.5%+34.5px)] rounded-[8px] top-[calc(50%+195px)] w-[71px]">
      <img loading="lazy" decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[8px] size-full" src={imgFrame2106258466} />
    </div>
  );
}

function FeatureWhySie() {
  return (
    <div className="absolute bg-[#faf0d7] h-[1267px] left-0 overflow-clip top-[770px] w-full" data-name="Feature why SIE">
      <Group />
      <Frame5 />
      <div className="-translate-x-1/2 absolute flex h-[274px] items-center justify-center left-[calc(50%-1px)] top-[20px] w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[274px]">
            <div className="absolute inset-[-0.5px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 274 0.5">
                <line id="Line 45" stroke="var(--stroke-0, #C98F00)" strokeWidth="0.5" x2="274" y1="0.25" y2="0.25" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="-translate-x-1/2 absolute flex h-[133px] items-center justify-center left-[calc(50%-1px)] top-[547px] w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[133px]">
            <div className="absolute inset-[-0.5px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 133 0.5">
                <line id="Line 49" stroke="var(--stroke-0, #C98F00)" strokeWidth="0.5" x2="133" y1="0.25" y2="0.25" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="-translate-x-1/2 absolute flex h-[287px] items-center justify-center left-1/2 top-[915px] w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[287px]">
            <div className="absolute inset-[-0.5px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 287 0.5">
                <line id="Line 46" stroke="var(--stroke-0, #C98F00)" strokeWidth="0.5" x2="287" y1="0.25" y2="0.25" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex h-0 items-center justify-center left-[calc(87.5%-7px)] top-[calc(50%-0.5px)] w-[248px]">
        <div className="flex-none rotate-180">
          <div className="h-0 relative w-[248px]">
            <div className="absolute inset-[-0.5px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 248 0.5">
                <line id="Line 47" stroke="var(--stroke-0, #C98F00)" strokeWidth="0.5" x2="248" y1="0.25" y2="0.25" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex h-0 items-center justify-center left-[calc(12.5%-5px)] top-[calc(50%-0.5px)] w-[248px]">
        <div className="flex-none rotate-180">
          <div className="h-0 relative w-[248px]">
            <div className="absolute inset-[-0.5px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 248 0.5">
                <line id="Line 47" stroke="var(--stroke-0, #C98F00)" strokeWidth="0.5" x2="248" y1="0.25" y2="0.25" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute h-[50px] left-[calc(41.67%+71px)] top-[328px] w-[104px]" data-name="Component 20">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgComponent21} />
      </div>
    </div>
  );
}

function Frame2({ heroPortraitImg }: { heroPortraitImg: string }) {
  return (
    <div className="absolute content-stretch flex flex-col items-center left-[calc(33.33%+49px)] top-[233px] w-[382px]">
      <div className="h-[268px] relative shrink-0 w-[210px]" data-name="image 55">
        <img decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={heroPortraitImg} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// DYNAMIC HERO SECTION
// ─────────────────────────────────────────────────────────────────────────────

function Frame1({
  heroPortraitImg,
  boxRef,
  onActivate,
}: {
  heroPortraitImg: string;
  boxRef?: RefObject<HTMLDivElement>;
  onActivate?: () => void;
}) {
  return (
    <div
      className="group/hero -translate-x-1/2 absolute content-stretch flex flex-col items-center justify-center left-[calc(50%-0.5px)] top-[238px] w-[255px]"
      onClick={onActivate}
      style={onActivate ? { cursor: 'pointer', zIndex: 10 } : undefined}
    >
      <div ref={boxRef} className="h-[262.368px] pointer-events-none relative shrink-0 w-[205px]" data-name="image 55">
        <img decoding="async" alt="" className="absolute inset-0 max-w-none object-cover size-full transition-[filter] duration-700 ease-out group-hover/hero:brightness-[1.05]" src={heroPortraitImg} />
        <div aria-hidden className="absolute border-[#d5c9a8] border-[5.4px] border-solid inset-[-5.4px] transition-shadow duration-700 ease-out group-hover/hero:shadow-[0_18px_50px_-20px_rgba(60,40,10,0.55)]" />
      </div>
    </div>
  );
}

interface HeroPanelProps {
  bgColor: string;
  patternImg?: string;
  texturImg: string;
  heroPortraitImg: string;
  projectName: string;
  description: string;
  opacity: number;
  onActivate?: (rect: SharedRect, src: string) => void;
}

const HeroPanel = memo(function HeroPanel({
  bgColor,
  patternImg,
  texturImg,
  heroPortraitImg,
  projectName,
  description,
  opacity,
  onActivate,
}: HeroPanelProps) {
  const boxRef = useRef<HTMLDivElement>(null);

  // Measure the framed portrait box and hand its rect to the transition layer
  const activate = useCallback(() => {
    if (!boxRef.current || !onActivate) return;
    const r = boxRef.current.getBoundingClientRect();
    onActivate(
      { top: r.top, left: r.left, width: r.width, height: r.height },
      heroPortraitImg
    );
  }, [onActivate, heroPortraitImg]);

  return (
    <div
      className="absolute h-[780px] left-0 overflow-clip top-0 w-full"
      style={{
        opacity,
        clipPath: opacity < 1 ? 'inset(0 100% 0 0)' : 'inset(0 0% 0 0)',
        transition: `opacity 200ms ease, clip-path 900ms cubic-bezier(0.76,0,0.24,1)`,
        willChange: 'opacity, clip-path',
      }}
      data-name="hero-panel"
    >
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0" style={{ backgroundColor: bgColor }} />
        <img loading="lazy" decoding="async" alt="" className="absolute max-w-none object-cover opacity-3 size-full" src={texturImg} />
      </div>
      {patternImg ? (
        <div
          className="absolute bg-size-[auto_auto,1490px_1053.4765625px] bg-top-left h-[1024px] top-[-634px] w-full"
          style={{ backgroundImage: `linear-gradient(90deg, ${bgColor}66 0%, ${bgColor}66 100%), url("${patternImg}")` }}
          data-name="pattern-overlay"
        />
      ) : null}
      <Frame1 heroPortraitImg={heroPortraitImg} boxRef={boxRef} onActivate={onActivate ? activate : undefined} />
      <p
        className="[word-break:break-word] absolute bottom-[144px] font-['Cormorant_Garamond',serif] font-light leading-[normal] left-[33px] not-italic text-[#b3ae85] text-[100px] translate-y-full uppercase whitespace-nowrap"
        onClick={onActivate ? activate : undefined}
        style={onActivate ? { cursor: 'pointer' } : undefined}
      >
        {projectName}
      </p>
      <p className="[word-break:break-word] absolute bottom-[108px] font-['Inter',sans-serif] font-normal leading-[normal] left-[calc(74%+26px)] not-italic text-[#b3ae85] text-[14px] translate-y-full w-[335px]">
        {description}
      </p>
      <div className="absolute h-[42px] left-[24px] top-[30px] w-[84px]" data-name="Primary Logos">
        <img decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgPrimaryLogos} />
      </div>
    </div>
  );
});

function CyclingHero() {
  const [currentIdx, setCurrentIdx]   = useState(0);
  const [nextIdx, setNextIdx]         = useState<number | null>(null);
  const [nextOpacity, setNextOpacity] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    timerRef.current = setTimeout(function cycle() {
      const next = (currentIdx + 1) % HOME_PROJECTS.length;
      setNextIdx(next);
      setNextOpacity(0);
      requestAnimationFrame(() => {
        requestAnimationFrame(() => { setNextOpacity(1); });
      });
      setTimeout(() => {
        setCurrentIdx(next);
        setNextIdx(null);
        setNextOpacity(0);
        timerRef.current = setTimeout(cycle, CYCLE_MS);
      }, FADE_MS + 50);
    }, CYCLE_MS);
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [currentIdx]);

  const current = HOME_PROJECTS[currentIdx];
  const next    = nextIdx !== null ? HOME_PROJECTS[nextIdx] : null;

  const { startTransition } = useTransition();

  // Build the click handler for a given project slug:
  // capture the image rect → start the morph → navigate after a short beat
  // so the cream backdrop can cover the route swap.
  const makeActivate = useCallback(
    (slug: string) => (rect: SharedRect, src: string) => {
      // Small screens / no shared hero → plain navigation
      if (typeof window !== "undefined" && window.innerWidth < 1024) {
        navigate(slug);
        return;
      }
      startTransition({
        src,
        rect,
        borderColor: "#d5c9a8", // Home frame cream
        borderWidth: 5.4,
      });
      window.setTimeout(() => navigate(slug), 300);
    },
    [navigate, startTransition]
  );

  return (
    <div className="absolute h-[780px] left-0 top-0 w-full" style={{ zIndex: 0 }}>
      <HeroPanel bgColor={current.bgColor} patternImg={current.patternImg} texturImg={current.textureImg} heroPortraitImg={current.heroImg} projectName={current.projectName} description={current.description} opacity={1} onActivate={makeActivate(current.slug)} />
      {next && (
        <HeroPanel bgColor={next.bgColor} patternImg={next.patternImg} texturImg={next.textureImg} heroPortraitImg={next.heroImg} projectName={next.projectName} description={next.description} opacity={nextOpacity} onActivate={makeActivate(next.slug)} />
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MIDDLE SECTION
// ─────────────────────────────────────────────────────────────────────────────

function Component1({ project }: { project: HomeProject }) {
  return (
    <div className="absolute h-[780px] left-0 overflow-clip top-0 w-full" data-name="28" style={{ backgroundColor: project.bgColor }}>
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0" style={{ backgroundColor: project.bgColor }} />
        <img loading="lazy" decoding="async" alt="" className="absolute max-w-none object-cover opacity-3 size-full" src={project.textureImg} />
      </div>
      {project.patternImg && (
        <div className="absolute h-[486px] left-[-47px] top-[-96px] w-[1534px]" data-name="Pattern6 4">
          <div className="absolute inset-0 opacity-20 overflow-hidden pointer-events-none">
            <img loading="lazy" decoding="async" alt="" className="absolute h-[239.47%] left-[-5.09%] max-w-none top-[-139.47%] w-[107.26%]" src={project.patternImg} />
          </div>
        </div>
      )}
      <p className="[word-break:break-word] absolute bottom-[140px] font-['Canela_Web:Light',sans-serif] leading-[normal] left-[24px] not-italic text-[112px] text-[rgba(253,235,206,0.49)] translate-y-full uppercase whitespace-nowrap">
        {project.projectName}
      </p>
      <div className="absolute h-[42px] left-[24px] top-[30px] w-[84px]" data-name="Primary Logos" />
      <p className="[word-break:break-word] absolute bottom-[98px] font-['Hanken_Grotesk',sans-serif] leading-[normal] left-[calc(75%+25px)] not-italic text-[rgba(253,235,206,0.49)] text-[12px] translate-y-full w-[305px]">
        {project.description}
      </p>
      <div className="absolute h-[52px] left-[11px] top-[20px] w-[104px]" data-name="Component 20">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgComponent22} />
      </div>
      <div className="absolute h-[268px] left-[calc(41.67%+3px)] pointer-events-none top-[233px] w-[210px]" data-name="image 55">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 max-w-none object-cover size-full" src={project.heroImg} />
        <div aria-hidden className="absolute border-5 border-[#fff6d9] border-solid inset-[-5px]" />
      </div>
      <div className="absolute h-[780px] left-[11px] top-0 w-full">
        <div aria-hidden className="absolute inset-0 pointer-events-none">
          <div className="absolute bg-[rgba(124,80,76,0.1)] inset-0" />
          <img loading="lazy" decoding="async" alt="" className="absolute max-w-none object-cover opacity-5 size-full" src={imgRectangle30} />
        </div>
      </div>
      <CyclingHero />
    </div>
  );
}

function Group1({ project }: { project: HomeProject }) {
  return (
    <div className="absolute contents left-0 top-0">
      <p className="[word-break:break-word] absolute bottom-[94px] font-['Neue_Haas_Grotesk_Display_Pro:45_Light',sans-serif] leading-[normal] left-[calc(75%+85px)] not-italic text-[14px] text-white tracking-[1px] translate-y-full w-[245px]">subtle, layered, and deeply calming, every corner is designed to be felt as much as it is seen.</p>
      <Frame2 heroPortraitImg={project.heroImg} />
      <Component1 project={project} />
    </div>
  );
}

function Component2({ project }: { project: HomeProject }) {
  return (
    <div className="absolute h-[780px] left-0 overflow-clip top-[2037px] w-full" data-name="1171" style={{ backgroundColor: project.bgColor }}>
      <div className="absolute h-[42px] left-[24px] top-[30px] w-[84px]" data-name="Primary Logos">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgPrimaryLogos} />
      </div>
      <Group1 project={project} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SERVICES SECTION
// ─────────────────────────────────────────────────────────────────────────────

function Frame16() {
  return (
    <div
      data-anim="reveal"
      data-anim-variant="text"
      data-anim-blur="6"
      className="[word-break:break-word] content-stretch flex flex-col gap-[20px] items-start not-italic relative shrink-0">
      <p className="capitalize font-['Instrument_Serif',sans-serif] leading-none relative shrink-0 text-[#5d5e36] text-[76px] w-[476px]">Full-Service Residential interior design</p>
      <p className="font-['Hanken_Grotesk',sans-serif] leading-[1.3] relative shrink-0 text-[#5c5d36] text-[22px] tracking-[0.5px] w-[476px]">Thoughtfully designed residential spaces from initial concept to final installation</p>
    </div>
  );
}

function Frame10() {
  return (
    <div
      data-anim="reveal"
      data-anim-variant="fade"
      data-anim-delay="0.15"
      className="group/btn cursor-pointer transition-[transform,filter] duration-500 ease-out will-change-transform hover:-translate-y-[2px] hover:brightness-110 content-stretch drop-shadow-[0px_114px_16px_rgba(0,0,0,0),0px_73px_14.5px_rgba(0,0,0,0.01),0px_41px_12.5px_rgba(0,0,0,0.05),0px_18px_9px_rgba(0,0,0,0.09),0px_5px_5px_rgba(0,0,0,0.1)] flex items-center justify-center px-[28px] py-[14px] relative rounded-[4px] shrink-0">
      <div aria-hidden className="absolute inset-0 pointer-events-none rounded-[4px]">
        <div className="absolute bg-[#703000] inset-0 rounded-[4px]" />
        <img loading="lazy" decoding="async" alt="" className="absolute max-w-none object-cover opacity-76 rounded-[4px] size-full" src={imgFrame2106258506} />
      </div>
      <div aria-hidden className="absolute border border-[#391900] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="[word-break:break-word] font-['Inter',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[20px] text-[#d5c9a8] tracking-[-0.6px] whitespace-nowrap transition-transform duration-500 ease-out group-hover/btn:translate-x-[2px]">View all projects</p>
    </div>
  );
}

function Frame13() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[36px] items-start justify-center left-[63px] top-[246px]">
      <Frame16 />
      <Frame10 />
    </div>
  );
}

function Frame23() {
  return (
    <div
      data-anim="reveal"
      data-anim-variant="text"
      className="absolute content-stretch flex flex-col gap-[12px] items-start left-[101px] top-[174px] w-[129px]">
      <p className="[word-break:break-word] font-['Hanken_Grotesk',sans-serif] leading-none min-w-full not-italic relative shrink-0 text-[#5d5e36] text-[14px] tracking-[2.8px] uppercase w-[min-content]">Our Services</p>
      <div className="h-0 relative shrink-0 w-[82px]">
        <div className="absolute inset-[-0.6px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 82 0.6">
            <line id="Line 5" stroke="var(--stroke-0, #5E5E5E)" strokeWidth="0.6" x2="82" y1="0.3" y2="0.3" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-col gap-[12px] items-start justify-center leading-[normal] not-italic relative shrink-0 text-[#5c5d36]">
      <p className="font-['Instrument_Serif',sans-serif] relative shrink-0 text-[32px] whitespace-pre">{`Renovation, remodel \n& New construction        `}</p>
      <p className="font-['Hanken_Grotesk',sans-serif] relative shrink-0 text-[18px] w-[356px]">Complete home transformations brought to life through thoughtful design, material curation, and seamless execution.</p>
    </div>
  );
}

function Frame14() {
  return (
    <div
      data-anim="reveal"
      data-anim-variant="text"
      className="absolute content-stretch flex gap-[48px] items-start justify-center left-[calc(50%+47px)] top-[223px]">
      <p className="[word-break:break-word] font-['Instrument_Serif',sans-serif] leading-none not-italic relative shrink-0 text-[#5c5d36] text-[102px] whitespace-nowrap">01</p>
      <div className="flex h-[117px] items-center justify-center relative shrink-0 w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[117px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 117 1">
                <line id="Line 7" stroke="var(--stroke-0, #656565)" x2="117" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame11 />
      <div className="absolute left-[117px] size-[9px] top-[34px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
          <circle cx="4.5" cy="4.5" fill="var(--fill-0, #703000)" id="Ellipse 1" r="4.5" />
        </svg>
      </div>
    </div>
  );
}

function Frame12() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-col gap-[12px] items-start justify-center leading-[normal] not-italic relative shrink-0 text-[#5c5d36]">
      <p className="font-['Instrument_Serif',sans-serif] relative shrink-0 text-[32px] whitespace-nowrap">{`Furnishing & Styling`}</p>
      <p className="font-['Hanken_Grotesk',sans-serif] relative shrink-0 text-[18px] w-[312px]">Thoughtfully designed interiors with carefully curated furniture, lighting, accessories.</p>
    </div>
  );
}

function Frame15() {
  return (
    <div
      data-anim="reveal"
      data-anim-variant="text"
      data-anim-delay="0.12"
      className="absolute content-stretch flex gap-[48px] items-start justify-center left-[calc(50%+40px)] top-[465px]">
      <p className="[word-break:break-word] font-['Instrument_Serif',sans-serif] leading-none not-italic relative shrink-0 text-[#5c5d36] text-[102px] whitespace-nowrap">02</p>
      <div className="flex h-[117px] items-center justify-center relative shrink-0 w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[117px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 117 1">
                <line id="Line 7" stroke="var(--stroke-0, #656565)" x2="117" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame12 />
      <div className="absolute left-[132px] size-[9px] top-[14px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
          <circle cx="4.5" cy="4.5" fill="var(--fill-0, #703000)" id="Ellipse 1" r="4.5" />
        </svg>
      </div>
    </div>
  );
}

function ArrowNarrowDownSvgrepoCom() {
  return (
    <div className="relative size-[38px]" data-name="arrow-narrow-down-svgrepo-com 1">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38 38">
        <g id="arrow-narrow-down-svgrepo-com 1">
          <path d={svgPaths.pf347200} id="Vector" stroke="var(--stroke-0, #703000)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Frame18() {
  return (
    <div className="group/arrow cursor-pointer transition-transform duration-500 ease-out hover:scale-[1.07] absolute left-[calc(91.67%-3px)] rounded-[50px] size-[63px] top-[263px]">
      <div aria-hidden className="absolute bg-[rgba(255,255,255,0.04)] inset-0 pointer-events-none rounded-[50px] transition-colors duration-500 group-hover/arrow:bg-[rgba(112,48,0,0.06)]" />
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-x-1/2 -translate-y-1/2 absolute flex items-center justify-center left-[calc(50%+0.5px)] size-[38px] top-[calc(50%+0.5px)]">
          <div className="-rotate-90 flex-none transition-transform duration-500 ease-out group-hover/arrow:translate-x-[3px]"><ArrowNarrowDownSvgrepoCom /></div>
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_0px_4px_0px_rgba(0,0,0,0.25)]" />
      <div aria-hidden className="absolute border border-[#a69d83] border-solid inset-0 pointer-events-none rounded-[50px]" />
    </div>
  );
}

function Frame19() {
  return (
    <div className="group/arrow cursor-pointer transition-transform duration-500 ease-out hover:scale-[1.07] absolute left-[calc(91.67%-3px)] rounded-[50px] size-[63px] top-[475px]">
      <div aria-hidden className="absolute bg-[rgba(255,255,255,0.04)] inset-0 pointer-events-none rounded-[50px] transition-colors duration-500 group-hover/arrow:bg-[rgba(112,48,0,0.06)]" />
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-x-1/2 -translate-y-1/2 absolute flex items-center justify-center left-[calc(50%+0.5px)] size-[38px] top-[calc(50%+0.5px)]">
          <div className="-rotate-90 flex-none transition-transform duration-500 ease-out group-hover/arrow:translate-x-[3px]"><ArrowNarrowDownSvgrepoCom /></div>
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_0px_4px_0px_rgba(0,0,0,0.25)]" />
      <div aria-hidden className="absolute border border-[#a69d83] border-solid inset-0 pointer-events-none rounded-[50px]" />
    </div>
  );
}

function ServicesSection() {
  return (
    <div className="absolute h-[832px] left-0 overflow-clip top-[2817px] w-full" data-name="Services section">
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <img loading="lazy" decoding="async" alt="" className="absolute max-w-none object-cover size-full" src={imgServicesSection} />
        <div className="absolute bg-[rgba(218,208,173,0.95)] inset-0" />
      </div>
      <Frame13 />
      <Frame23 />
      <div className="absolute left-[calc(58.33%+93px)] size-[21px] top-[98px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21 21">
          <path d={svgPaths.pe8fa800} fill="var(--fill-0, #703000)" id="Star 2" />
        </svg>
      </div>
      <div className="absolute left-[63px] size-[16px] top-[174px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
          <path d={svgPaths.p24533600} fill="var(--fill-0, #703000)" id="Star 5" />
        </svg>
      </div>
      <div className="absolute left-[calc(66.67%+85px)] size-[21px] top-[409px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21 21">
          <path d={svgPaths.pe8fa800} fill="var(--fill-0, #703000)" id="Star 2" />
        </svg>
      </div>
      <div className="absolute left-[calc(58.33%+90px)] size-[21px] top-[683px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21 21">
          <path d={svgPaths.pe8fa800} fill="var(--fill-0, #703000)" id="Star 2" />
        </svg>
      </div>
      <div className="absolute flex h-[585px] items-center justify-center left-[calc(41.67%+10px)] top-[110px] w-[314px]">
        <div className="-rotate-90 -scale-y-100 flex-none">
          <div className="h-[314px] relative w-[585px]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 585.6 314.3">
              <path d={svgPaths.pa545880} id="Ellipse 3" stroke="var(--stroke-0, #656565)" strokeWidth="0.6" />
            </svg>
          </div>
        </div>
      </div>
      <Frame14 />
      <div className="absolute left-[calc(41.67%+5px)] size-[10px] top-[390px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
          <circle cx="5" cy="5" fill="var(--fill-0, #703000)" id="Ellipse 2" r="5" />
        </svg>
      </div>
      <Frame15 />
      <Frame18 />
      <Frame19 />
      <div className="absolute flex h-0 items-center justify-center left-[calc(50%+47px)] top-[421px] w-[269px]">
        <div className="flex-none rotate-180">
          <div className="h-0 relative w-[269px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 269 1">
                <line id="Line 3" stroke="var(--stroke-0, black)" strokeOpacity="0.22" x2="269" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-0 items-center justify-center left-[calc(75%+2px)] top-[421px] w-[293px]">
        <div className="flex-none rotate-180">
          <div className="h-0 relative w-[293px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 293 1">
                <line id="Line 6" stroke="var(--stroke-0, black)" strokeOpacity="0.22" x2="293" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// FOOTER / CONTACT
// ─────────────────────────────────────────────────────────────────────────────

function Frame20() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center justify-center relative shrink-0 w-[231px]">
      <p className="leading-none relative shrink-0 text-[36px] w-full">Contact</p>
      <p className="leading-[1.4] relative shrink-0 text-[19px] w-full">hello@studioinsideeye.com<br aria-hidden />San Jose, California</p>
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center justify-center leading-none relative shrink-0 w-[181px]">
      <p className="relative shrink-0 text-[32px] w-full">Menu</p>
      <div className="content-stretch flex flex-col gap-[11px] items-start relative shrink-0 text-[19px] w-full">
        {["Home","Moodboard","Philosophy","Services","Projects"].map(t => <p key={t} className="relative shrink-0 w-full">{t}</p>)}
      </div>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center justify-center leading-none relative shrink-0 w-[181px]">
      <p className="relative shrink-0 text-[32px] w-full">Projects</p>
      <div className="content-stretch flex flex-col gap-[11px] items-center justify-center relative shrink-0 text-[19px] w-full">
        {["SIENNA","Villa","Luxhill","Remeos"].map(t => <p key={t} className="relative shrink-0 w-full">{t}</p>)}
      </div>
    </div>
  );
}

function Frame26() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center justify-center leading-none relative shrink-0 w-[181px]">
      <p className="relative shrink-0 text-[32px] w-full">Socials</p>
      <div className="content-stretch flex flex-col gap-[11px] items-start relative shrink-0 text-[19px] w-full">
        {[
          { label: "Linkedin", href: "https://www.linkedin.com/in/haritha-prasad-a5b526208?utm_source=share_via&utm_content=profile&utm_medium=member_ios" },
          { label: "Instagram", href: "https://www.instagram.com/studioinsideeye?igsh=MWxvZ281YmhudTNv" },
          { label: "Yelp", href: "https://m.yelp.com/biz/the-inside-eye-design-studio-san-jose?dd_referrer=https%3A%2F%2Fwww.google.com%2F" },
        ].map(({ label, href }) => (
          <a key={label} href={href} target="_blank" rel="noopener noreferrer" className="relative shrink-0 w-full" style={{ textDecoration: "none", color: "inherit" }}>
            <p className="relative shrink-0 w-full">{label}</p>
          </a>
        ))}
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="[word-break:break-word] absolute content-stretch flex font-['Hanken_Grotesk',sans-serif] gap-[82px] items-start left-[calc(16.67%+1px)] not-italic text-[#d5c9a8] top-[394px]">
      <Frame20 /><Frame21 /><Frame24 /><Frame26 />
    </div>
  );
}

function Frame36({ slug }: { slug: string }) {
  const navigate = useNavigate();
  return (
    <div
      className="bg-[#d5c9a8] content-stretch flex items-center justify-center px-[28px] py-[16px] relative rounded-[4px] shrink-0 cursor-pointer hover:opacity-90 transition-opacity"
      onClick={() => navigate('/contact')}
    >
      <p className="[word-break:break-word] font-['Inter',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#442b00] text-[20px] tracking-[-0.6px] whitespace-nowrap">{` Start your project`}</p>
    </div>
  );
}

function Frame38({ slug }: { slug: string }) {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col items-center justify-center left-[calc(50%+2.5px)] top-[74px]">
      <div className="h-[102px] relative shrink-0 w-[203px]" data-name="Primary Logos">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgPrimaryLogos1} />
      </div>
      <p className="[word-break:break-word] font-['P22GrosvenorW00-Regular',serif] leading-[1.12] not-italic relative shrink-0 text-[#d5c9a8] text-[60px] whitespace-nowrap">Build your dream home</p>
      <Frame36 slug={slug} />
    </div>
  );
}

function Frame40() {
  return (
    <div className="[word-break:break-word] absolute content-stretch flex font-['Hanken_Grotesk',sans-serif] items-center justify-between leading-[normal] left-[34px] not-italic text-[12px] text-[rgba(238,221,160,0.7)] top-[810px] tracking-[0.5px] w-[1372px] whitespace-nowrap">
      <p className="relative shrink-0">©️2025 Studio Inside Eye. All rights reserved</p>
      <div className="content-stretch flex gap-[51px] items-center relative shrink-0">
        {["Privacy policy","Terms of service","Cookies Settings"].map(t => <p key={t} className="relative shrink-0">{t}</p>)}
      </div>
    </div>
  );
}

function ContactPage({ bgColor }: { bgColor: string }) {
  return (
    <div className="absolute h-[774px] left-0 top-[-57px] w-full" data-name="Contact Page">
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0" style={{ backgroundColor: bgColor, transition: `background-color ${FADE_MS}ms ease-in-out` }} />
        <img loading="lazy" decoding="async" alt="" className="absolute max-w-none object-cover opacity-8 size-full" src={imgContactPage} />
      </div>
      <div
        data-anim="reveal"
        data-anim-variant="fade"
        data-anim-delay="0.1"
        className="[word-break:break-word] absolute content-stretch flex font-['Hanken_Grotesk',sans-serif] gap-[82px] items-start left-[calc(8.33%+102px)] not-italic text-[#d5c9a8] top-[472px]">
        <Frame20 /><Frame21 /><Frame24 /><Frame26 />
      </div>
      <div className="absolute h-0 left-0 top-px w-full">
        <div className="absolute inset-[-0.8px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1440 0.8">
            <line id="Line 90" stroke="var(--stroke-0, #DACDAC)" strokeWidth="0.8" x2="1440" y1="0.4" y2="0.4" />
          </svg>
        </div>
      </div>
      <div className="-translate-x-1/2 absolute left-[calc(50%+0.5px)] size-[23px] top-[-11px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 23">
          <path d={svgPaths.p25b23d00} fill="var(--fill-0, #DAD0AD)" id="Star 7" />
        </svg>
      </div>
    </div>
  );
}

function Frame37({ bgColor, slug }: { bgColor: string; slug: string }) {
  const navigate = useNavigate();
  return (
    <div
      className="bg-[#d5c9a8] content-stretch flex items-center justify-center px-[28px] py-[16px] relative rounded-[4px] shrink-0 cursor-pointer transition-[transform,box-shadow,filter] duration-500 ease-out will-change-transform hover:-translate-y-[2px] hover:brightness-[1.03] hover:shadow-[0_14px_28px_-12px_rgba(0,0,0,0.45)]"
      onClick={() => navigate('/contact')}
    >
      <p
        className="[word-break:break-word] font-['Inter',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[20px] tracking-[-0.6px] whitespace-nowrap"
        style={{ color: bgColor, transition: `color ${FADE_MS}ms ease-in-out` }}
      >{` Start your project`}</p>
    </div>
  );
}

function Frame41({ bgColor, slug }: { bgColor: string; slug: string }) {
  return (
    <div
      data-anim="reveal"
      data-anim-variant="text"
      data-anim-blur="6"
      className="-translate-x-1/2 absolute content-stretch flex flex-col items-center justify-center left-[calc(50%+3px)] top-[97px]">
      <div className="h-[102px] relative shrink-0 w-[203px]" data-name="Primary Logos">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgPrimaryLogos2} />
      </div>
      <p className="[word-break:break-word] font-['P22GrosvenorW00-Regular',serif] leading-[1.12] not-italic relative shrink-0 text-[#d5c9a8] text-[60px] whitespace-nowrap">Build your dream home</p>
      <Frame37 bgColor={bgColor} slug={slug} />
    </div>
  );
}

function FeatureWhySie1({ project }: { project: HomeProject }) {
  return (
    <div
      className="absolute h-[620px] left-0 overflow-clip top-[4477px] w-full"
      data-name="Feature why SIE"
      style={{ backgroundColor: "#504d39" }}
    >
      <div className="absolute h-[660px] left-0 top-0 w-full">
        <div aria-hidden className="absolute inset-0 pointer-events-none">
          <div className="absolute bg-[rgba(124,80,76,0.1)] inset-0" />
          <img loading="lazy" decoding="async" alt="" className="absolute max-w-none object-cover opacity-5 size-full" src={imgRectangle30} />
        </div>
      </div>
      <Frame22 />
      <Frame38 slug={project.slug} />
      <Frame40 />
      <ContactPage bgColor={project.bgColor} />
      <Frame41 bgColor={project.bgColor} slug={project.slug} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// HERO IMAGE SECTION  —  crossfade transition on heroImgLandscape change
// ─────────────────────────────────────────────────────────────────────────────

function useCrossfade(src: string) {
  const [displayed, setDisplayed]             = useState(src);
  const [incoming, setIncoming]               = useState<string | null>(null);
  const [incomingOpacity, setIncomingOpacity] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (src === displayed) return;

    // mount new image at opacity 0
    setIncoming(src);
    setIncomingOpacity(0);

    // two rAFs to ensure browser paints the opacity-0 frame first
    requestAnimationFrame(() => {
      requestAnimationFrame(() => setIncomingOpacity(1));
    });

    // after fade completes → promote incoming to base, remove overlay
    timerRef.current = setTimeout(() => {
      setDisplayed(src);
      setIncoming(null);
      setIncomingOpacity(0);
    }, FADE_MS + 80);

    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [src]);                                    // displayed intentionally omitted

  return { displayed, incoming, incomingOpacity };
}

function ServicesSection1({ heroPortraitImg }: { heroPortraitImg: string }) {
  const { displayed, incoming, incomingOpacity } = useCrossfade(heroPortraitImg);

  return (
    <div className="absolute h-[877px] left-0 overflow-clip top-0 w-full" data-name="Services section">
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <img loading="lazy" decoding="async" alt="" className="absolute max-w-none object-cover size-full" src={imgServicesSection} />
        <div className="absolute bg-[rgba(218,208,173,0.95)] inset-0" />
      </div>
      <div
        data-anim="reveal"
        data-anim-variant="zoom"
        className="absolute h-[751px] left-[33px] top-[63px] right-[33px]" data-name="hero-photo">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">

          {/* Base layer — always visible, no transition needed */}
          <img
            decoding="async"
            alt=""
            className="absolute h-[130.42%] left-[-0.02%] max-w-none top-0 w-[100.03%]"
            src={displayed}
          />

          {/* Incoming layer — crossfades in on top, then unmounts */}
          {incoming && (
            <img
              decoding="async"
              alt=""
              className="absolute h-[130.42%] left-[-0.02%] max-w-none top-0 w-[100.03%]"
              src={incoming}
              style={{
                opacity: incomingOpacity,
                transition: `opacity ${FADE_MS}ms cubic-bezier(0.4, 0, 0.2, 1)`,
                willChange: "opacity",
              }}
            />
          )}

        </div>
      </div>
    </div>
  );
}

function Component3({ project }: { project: HomeProject }) {
  return (
    <div className="absolute bg-[#dad0ad] h-[868px] left-0 overflow-clip top-[3609px] w-full" data-name="1172">
      <ServicesSection1 heroPortraitImg={project.heroImgLandscape ?? project.heroImg} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MOBILE / TABLET COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Mobile — Two images from desktop top-right, shown at the very top (top: 0).
 * Left image is shorter, right image is taller — mirroring the desktop feel.
 */


/** Mobile Header strip — cream bg, logo + hamburger */
/** Mobile — Header floats OVER images, both start from top: 0 */
/** Mobile — Header floats OVER images, both start from top: 0 */
function MobileHeroTop() {
  return (
    <div
      className="relative w-full overflow-hidden"
      style={{ backgroundColor: 'rgba(254,244,219,0.97)' }}
    >
      {/* Subtle background texture */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden>
        <img
          loading="lazy"
          decoding="async"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-[0.05]"
          src={imgEntireWebsite}
        />
      </div>

      {/* Images — both start from top: 0, items-start se */}
      <div
        className="relative flex items-start justify-center gap-0"
        style={{ zIndex: 1 }}
        data-anim="reveal"
        data-anim-variant="zoom"
      >
        {/* Left image — chhoti height, top se start */}
        <div
  className="shrink-0 overflow-hidden"
  style={{
    width: 'clamp(145px, 36vw, 272px)',
    height: 'clamp(150px, 32vw, 230px)',
    marginRight: '-7vh',
  }}
  
>
  <img
    loading="lazy"
    decoding="async"
    alt=""
    className="w-full h-full object-cover object-bottom"
    src={imgImage48}
  />
</div>

        {/* Right image — badi height, top se start */}
        <div
          className="shrink-0 overflow-hidden"
          style={{
            width: 'clamp(145px, 36vw, 272px)',
            height: 'clamp(220px, 54vw, 380px)',
            
          }}
        >
          <img
            loading="lazy"
            decoding="async"
            alt=""
            className="w-full h-full object-cover"
            src={imgImage48}
          />
        </div>
      </div>

      {/* Header — absolute, images ke upar float karta hai */}
      <div
        className="absolute top-0 left-0 w-full"
        style={{ zIndex: 20, height: 72 }}
      >
        <JournalHeader activePage="Home" />
      </div>
    </div>
  );
}

/** Mobile — tagline text + image collage / moodboard strip (text first, then images) */
function MobileImageCollage() {
  return (
    <div
      className="relative w-full overflow-hidden"
      style={{ background: 'rgba(254,244,219,0.97)' }}
    >
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 w-full h-full object-cover opacity-[0.06]" src={imgEntireWebsite} />
      </div>

      {/* Studio tagline text — FIRST */}
      <div data-anim="reveal" data-anim-variant="text" data-anim-blur="6" className="relative px-5 pt-6 pb-5 text-end">
  <p
    className="font-['Instrument_Serif'] italic text-[#703000] leading-[1.1] mb-1"
    style={{ fontSize: 'clamp(36px, 11vw, 60px)', letterSpacing: '-0.02em' }}
  >
    Studio Inside Eye
  </p>
  <p
    className="font-['IBM_Plex_Serif',serif] text-[#553319] leading-[1.3]"
    style={{ fontSize: 'clamp(12px, 3.2vw, 16px)' }}
  >
    A <strong>Boutique Interior Design Studio</strong> Creating Spaces That Are Rooted, Intentional, And Designed For You.
  </p>
</div>

      {/* Photo strip — Figma layout: left 2 stacked + right 1 big */}
      <div data-anim="reveal" data-anim-variant="zoom" className="relative px-4 pb-5">
        <div className="flex gap-2 items-stretch">

          {/* Left column — 2 images stacked */}
          <div className="flex flex-col gap-2" style={{ width: 'clamp(100px, 26vw, 190px)' }}>
            <div className="overflow-hidden rounded-[2px]" style={{ height: 'clamp(120px, 28vw, 210px)' }}>
              <img loading="lazy" decoding="async" alt="" className="w-full h-full object-cover" src={imgFrame2106258503} />
            </div>
            <div className="overflow-hidden rounded-[2px]" style={{ height: 'clamp(120px, 28vw, 210px)' }}>
              <img loading="lazy" decoding="async" alt="" className="w-full h-full object-cover" src={imgFrame2106258500} />
            </div>
          </div>

          {/* Right image — badi, full height */}
          <div className="flex-1 overflow-hidden rounded-[2px]" style={{ height: 'clamp(248px, 58vw, 428px)' }}>
            <img loading="lazy" decoding="async" alt="" className="w-full h-full object-cover" src={imgFrame2106258502} />
          </div>

        </div>
      </div>
    </div>
  );
}

/** Mobile — "Why SIE" / about section */
function MobileWhySIE() {
  return (
    <div className="bg-[#faf0d7] w-full overflow-hidden px-5 py-12">
      <div className="flex justify-center mb-6">
        <div className="h-16 w-px bg-[#C98F00] opacity-60" />
      </div>
      <div className="flex justify-center mb-8">
        <div className="relative h-[44px] w-[88px]">
          <img loading="lazy" decoding="async" alt="" className="absolute inset-0 w-full h-full object-cover pointer-events-none" src={imgComponent21} />
        </div>
      </div>
      <p
        className="font-['Instrument_Serif',sans-serif] not-italic text-[#5d5e36] text-center leading-[1.2] mb-6 mx-auto"
        style={{ fontSize: 'clamp(22px, 6vw, 32px)', maxWidth: 480, letterSpacing: '-0.03em' }}
      >
        Designing timeless residential interiors for modern California, across San Jose and the Bay Area.
      </p>
      <div className="flex justify-center mb-6">
        <div className="h-10 w-px bg-[#C98F00] opacity-60" />
      </div>
      <p
        className="font-['Instrument_Serif',sans-serif] not-italic text-[#5d5e36] text-center leading-[1.25] mx-auto"
        style={{ fontSize: 'clamp(20px, 5.5vw, 28px)', maxWidth: 440, letterSpacing: '-0.02em' }}
        data-anim="reveal"
        data-anim-variant="text"
        data-anim-blur="6"
      >
        At Studio Inside Eye, every space starts with you. We design around how you live, what you need, what you value.
      </p>
      <div className="flex justify-center mt-8">
        <div className="h-16 w-px bg-[#C98F00] opacity-60" />
      </div>
    </div>
  );
}

/** Mobile/Tablet — Project hero panel (static, shows current cycling project) */
function MobileProjectHero({ project }: { project: HomeProject }) {
  const navigate = useNavigate();
  return (
    <div
      className="relative w-full overflow-hidden"
      style={{ backgroundColor: project.bgColor, minHeight: 580 }}
    >
      <img loading="lazy" decoding="async" alt="" className="absolute inset-0 w-full h-full object-cover opacity-[0.03] pointer-events-none" src={project.textureImg} />
      {project.patternImg && (
        <div
        className="absolute inset-0 opacity-15 bottom-2/3"
          style={{ backgroundImage: `url("${project.patternImg}")`, backgroundSize: 'cover', backgroundPosition: 'center' }}
        />
      )}

      {/* Portrait image — clickable */}
      <div
        className="relative z-10 flex justify-center pt-10 pb-6 cursor-pointer"
        onClick={() => navigate(project.slug)}
        data-anim="reveal"
        data-anim-variant="zoom"
      >
        <div className="relative" style={{ width: 'clamp(190px, 42vw, 280px)', height: 'clamp(240px, 52vw, 360px)' }}>
          <img loading="lazy" decoding="async" alt="" className="absolute inset-0 w-full h-full object-cover" src={project.heroImg} />
          <div aria-hidden className="absolute border-[4px] border-solid" style={{ borderColor: '#fff6d9', inset: '-4px' }} />
        </div>
      </div>

      {/* Project name — clickable */}
      <p
        className="relative text-center z-10 px-5 font-['Cormorant_Garamond',serif] font-light uppercase text-[rgba(253,235,206,0.55)] leading-none mb-6 mt-4 cursor-pointer"
        style={{ fontSize: 'clamp(52px, 16vw, 84px)', letterSpacing: '-0.02em' }}
        onClick={() => navigate(project.slug)}
        data-anim="reveal"
        data-anim-variant="text"
        data-anim-blur="8"
        data-anim-delay="0.08"
      >
        {project.projectName}
      </p>
      <p
        className="relative z-10 px-5 text-center pb-5 font-['Hanken_Grotesk',sans-serif] leading-[1.5] text-[rgba(253,235,206,0.55)] "
        style={{ fontSize: 'clamp(12px, 3.2vw, 14px)' }}
      >
        {project.description}
      </p>
    </div>
  );
}

/** Mobile/Tablet — Services section */
function MobileServicesSection() {
  return (
    <div className="relative w-full overflow-hidden">
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 w-full h-full object-cover" src={imgServicesSection} />
        <div className="absolute inset-0 bg-[rgba(218,208,173,0.95)]" />
      </div>

      <div className="relative px-5 pt-10 pb-10">
        {/* Section label */}
        <div className="flex items-center gap-3 mb-6" data-anim="reveal" data-anim-variant="text">
          <svg className="shrink-0" width="10" height="10" viewBox="0 0 16 16" fill="none">
            <path d={svgPaths.p24533600} fill="#703000" />
          </svg>
          <p className="font-['Hanken_Grotesk',sans-serif] text-[#5d5e36] text-[11px] tracking-[2.5px] uppercase leading-none">Our Services</p>
        </div>

        <p
          className="font-['Instrument_Serif',sans-serif] text-[#5d5e36] capitalize leading-[1.1] mb-3"
          style={{ fontSize: 'clamp(34px, 9vw, 56px)', letterSpacing: '-0.02em' }}
          data-anim="reveal"
          data-anim-variant="text"
          data-anim-blur="6"
          data-anim-delay="0.06"
        >
          Full-Service Residential interior design
        </p>
        <p
          className="font-['Hanken_Grotesk',sans-serif] text-[#5c5d36] leading-[1.4] mb-10"
          style={{ fontSize: 'clamp(14px, 4vw, 18px)', letterSpacing: '0.02em' }}
        >
          Thoughtfully designed residential spaces from initial concept to final installation
        </p>

        <div className="w-full h-px mb-8" style={{ background: 'rgba(0,0,0,0.12)' }} />

        {/* Service 01 */}
        <div className="mb-8 md:flex md:gap-12 md:items-start" data-anim="reveal" data-anim-variant="text" data-anim-delay="0.04">
          <div className="flex items-start gap-4 mb-3 md:flex-1">
            <p
              className="font-['Instrument_Serif',sans-serif] text-[#5c5d36] leading-none shrink-0"
              style={{ fontSize: 'clamp(52px, 14vw, 76px)' }}
            >01</p>
            <div className="pt-3">
              <p
                className="font-['Instrument_Serif',sans-serif] text-[#5c5d36] leading-[1.15] mb-2"
                style={{ fontSize: 'clamp(20px, 5.5vw, 28px)' }}
              >
                Renovation, remodel{'\n'}& New construction
              </p>
              <p
                className="font-['Hanken_Grotesk',sans-serif] text-[#5c5d36] leading-[1.4]"
                style={{ fontSize: 'clamp(13px, 3.5vw, 16px)' }}
              >
                Complete home transformations brought to life through thoughtful design, material curation, and seamless execution.
              </p>
            </div>
          </div>
        </div>

        <div className="w-full h-px mb-8" style={{ background: 'rgba(0,0,0,0.12)' }} />

        {/* Service 02 */}
        <div className="mb-10 md:flex md:gap-12 md:items-start" data-anim="reveal" data-anim-variant="text" data-anim-delay="0.12">
          <div className="flex items-start gap-4 mb-3 md:flex-1">
            <p
              className="font-['Instrument_Serif',sans-serif] text-[#5c5d36] leading-none shrink-0"
              style={{ fontSize: 'clamp(52px, 14vw, 76px)' }}
            >02</p>
            <div className="pt-3">
              <p
                className="font-['Instrument_Serif',sans-serif] text-[#5c5d36] leading-[1.15] mb-2"
                style={{ fontSize: 'clamp(20px, 5.5vw, 28px)' }}
              >
                Furnishing & Styling
              </p>
              <p
                className="font-['Hanken_Grotesk',sans-serif] text-[#5c5d36] leading-[1.4]"
                style={{ fontSize: 'clamp(13px, 3.5vw,16px)' }}
              >
                Thoughtfully designed interiors with carefully curated furniture, lighting, accessories.
              </p>
            </div>
          </div>
        </div>

        <div className="flex">
          <button
            className="relative flex items-center justify-center rounded-[4px] font-['Inter',sans-serif] font-medium text-[#d5c9a8]tracking-[-0.02em] cursor-pointer hover:opacity-90 transition-opacity"
            style={{ background: '#703000', padding: '14px 28px', fontSize: 'clamp(14px, 3.5vw, 17px)' }}
          >
            View all projects
          </button>
        </div>
      </div>
    </div>
  );
}

/** Mobile/Tablet — Landscape hero image — crossfade transition */
function MobileLandscapePhoto({ project }: { project: HomeProject }) {
  const heroSrc = project.heroImgLandscape ?? project.heroImg;
  const { displayed, incoming, incomingOpacity } = useCrossfade(heroSrc);

  return (
    <div className="relative w-full overflow-hidden bg-[#dad0ad]" style={{ minHeight: 260 }}>
      <div aria-hidden className="absolute inset-0 pointer-events-none">
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 w-full h-full object-cover" src={imgServicesSection} />
        <div className="absolute inset-0 bg-[rgba(218,208,173,0.92)]" />
      </div>
      <div className="relative px-4 py-4">
        <div
          className="w-full overflow-hidden rounded-[2px] relative"
          style={{ height: 'clamp(220px, 55vw, 380px)' }}
          data-anim="reveal"
          data-anim-variant="zoom"
        >
          {/* Base layer */}
          <img
            decoding="async"
            alt=""
            className="absolute inset-0 w-full h-full object-cover"
            src={displayed}
          />

          {/* Incoming layer — crossfades in on top, then unmounts */}
          {incoming && (
            <img
              decoding="async"
              alt=""
              className="absolute inset-0 w-full h-full object-cover"
              src={incoming}
              style={{
                opacity: incomingOpacity,
                transition: `opacity ${FADE_MS}ms cubic-bezier(0.4, 0, 0.2, 1)`,
                willChange: "opacity",
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// "in" glyph (LinkedIn) — drawn without its own background, since the
// surrounding tile already supplies the beige square.
const LINKEDIN_PATH =
  "M5.46 7.43h-.02c-1.22 0-2-.83-2-1.87 0-1.06.81-1.87 2.05-1.87 1.24 0 2 .8 2.02 1.87 0 1.04-.78 1.87-2.05 1.87zM7.27 20.1H3.65V9h3.62v11.1zM20.34 20.1h-3.62v-5.8c0-1.45-.52-2.45-1.83-2.45-1 0-1.6.67-1.86 1.33-.1.23-.12.55-.12.88v6.04h-3.62s.05-9.79 0-10.8h3.62v1.53a3.6 3.6 0 0 1 3.26-1.79c2.39 0 4.18 1.56 4.18 4.89v6.17z";

/** Beige square social icon tile used in the mobile footer */
function MobileFooterSocialIcon({ path, href }: { path: string; href?: string }) {
  const tile = (
    <div
      className="flex items-center justify-center rounded-[8px] flex-shrink-0"
      style={{ backgroundColor: "#dad0ad", width: 48, height: 48 }}
    >
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d={path} fill="#5C593E" />
      </svg>
    </div>
  );
  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" style={{ display: "inline-flex" }}>
        {tile}
      </a>
    );
  }
  return tile;
}

/** Mobile/Tablet — Footer / Contact section */
function MobileFooter({ project }: { project: HomeProject }) {
  const navigate = useNavigate();
  return (
    <div
      className="relative w-full overflow-hidden"
      style={{ backgroundColor: project.bgColor, transition: `background-color ${FADE_MS}ms ease-in-out` }}
    >
      {/* Background texture */}
      <div aria-hidden className="absolute inset-0 pointer-events-none" style={{ zIndex: 0 }}>
        <div className="absolute inset-0 bg-[rgba(124,80,76,0.08)]" />
        <img loading="lazy" decoding="async" alt="" className="absolute inset-0 w-full h-full object-cover opacity-[0.05]" src={imgRectangle30} />
      </div>

      {/* Star separator */}
      <div className="relative flex justify-center pt-6" style={{ zIndex: 1 }}>
        <div className="w-full h-px" style={{ background: 'rgba(218,205,172,0.3)' }} />
      </div>
      <div className="relative flex justify-center -mt-3" style={{ zIndex: 2 }}>
        <svg width="23" height="23" viewBox="0 0 23 23" fill="none">
          <path d={svgPaths.p25b23d00} fill="#DAD0AD" />
        </svg>
      </div>

      <div className="relative px-5 pt-8 pb-8" style={{ zIndex: 1 }}>

        <div className="flex flex-col items-center gap-5 mb-10 pt-2" data-anim="reveal" data-anim-variant="fade" data-anim-delay="0.05">
          <div className="relative flex justify-center">
            <div className="relative" style={{ height: 70, width: 140 }}>
              <img loading="lazy" decoding="async" alt="" className="absolute inset-0 w-full h-full object-cover pointer-events-none" src={imgPrimaryLogos2} />
            </div>
          </div>

          {/* Small star + vertical divider, beneath the logo */}
          <div className="flex flex-col items-center">
            <svg width="15" height="15" viewBox="0 0 23 23" fill="none">
              <path d={svgPaths.p25b23d00} fill="#DAD0AD" />
            </svg>
            <div className="w-px mt-3" style={{ height: 56, background: 'rgba(218,205,172,0.35)' }} />
          </div>

          <p
            className="font-['P22GrosvenorW00-Regular',serif] leading-[1.1] not-italic text-[#d5c9a8] text-center mt-3"
            style={{ fontSize: 'clamp(24px, 7vw, 40px)' }}
          >
            Build your dream home
          </p>
          <button
            className="flex items-center justify-center rounded-[4px] font-['Inter',sans-serif] font-medium tracking-[-0.02em] cursor-pointer hover:opacity-90 transition-opacity"
            style={{
              background: '#d5c9a8',
              color: project.bgColor,
              padding: '14px 28px',
              fontSize: 'clamp(14px, 3.8vw, 18px)',
              transition: `color ${FADE_MS}ms ease-in-out`,
            }}
            onClick={() => navigate('/contact')}
          >
            Start your project
          </button>
        </div>

        {/* Horizontal divider with star, centered */}
        <div className="relative flex justify-center mb-8">
          <div className="w-full h-px" style={{ background: 'rgba(218,205,172,0.3)' }} />
          <div className="absolute" style={{ top: '50%', transform: 'translateY(-50%)' }}>
            <svg width="23" height="23" viewBox="0 0 23 23" fill="none">
              <path d={svgPaths.p25b23d00} fill="#DAD0AD" />
            </svg>
          </div>
        </div>

        {/* Social icons */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <MobileFooterSocialIcon
            path={socialSvgPaths.p2ea55bf0}
            href="https://www.instagram.com/studioinsideeye?igsh=MWxvZ281YmhudTNv"
          />
          <MobileFooterSocialIcon
            path={LINKEDIN_PATH}
            href="https://www.linkedin.com/in/haritha-prasad-a5b526208?utm_source=share_via&utm_content=profile&utm_medium=member_ios"
          />
          <MobileFooterSocialIcon path={socialSvgPaths.p1dbc3000} />
        </div>

        {/* Divider */}
        <div className="w-full h-px mb-5" style={{ background: 'rgba(218,205,172,0.25)' }} />

        {/* Copyright */}
        <p
          className="font-['Hanken_Grotesk',sans-serif] text-[rgba(238,221,160,0.65)] tracking-[0.02em] text-center"
          style={{ fontSize: 'clamp(10px, 2.5vw, 12px)' }}
        >
          ©️2025 Studio Inside Eye. All rights reserved
        </p>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// DESKTOP "SCALE-TO-FIT" CANVAS
// ─────────────────────────────────────────────────────────────────────────────
const DESKTOP_MIN_WIDTH = 1024;
const CANVAS_WIDTH = 1440;
const CANVAS_HEIGHT = 5097;

function computeDesktopScale(viewportWidth: number): number {
  if (viewportWidth >= CANVAS_WIDTH) return 1;
  if (viewportWidth >= DESKTOP_MIN_WIDTH) return viewportWidth / CANVAS_WIDTH;
  return 1;
}

function useDesktopScale(): number {
  const [scale, setScale] = useState<number>(() =>
    typeof window === "undefined" ? 1 : computeDesktopScale(window.innerWidth),
  );
  useEffect(() => {
    let frame = 0;
    const onResize = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => setScale(computeDesktopScale(window.innerWidth)));
    };
    onResize();
    window.addEventListener("resize", onResize);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("resize", onResize);
    };
  }, []);
  return scale;
}

// ─────────────────────────────────────────────────────────────────────────────
// ROOT HOME COMPONENT
// ─────────────────────────────────────────────────────────────────────────────

export default function Home() {
  const [activeIdx, setActiveIdx] = useState(0);
  const desktopScale = useDesktopScale();
  const isScaled = desktopScale < 1;

  // ── Motion engine ──────────────────────────────────────────────────────────
  // Motion roots — the entrance + scroll choreography is scoped to each layout.
  // Purely additive: never reads, sets or changes layout. The project-hero /
  // shared-element region is intentionally left untagged, so the Home → Project
  // morph keeps measuring an identical, untouched box.
  const desktopMotionRef = useRef<HTMLDivElement>(null);
  const mobileMotionRef = useRef<HTMLDivElement>(null);
  useReveal(desktopMotionRef, { enableParallax: true });
  useReveal(mobileMotionRef, { enableParallax: false });

  useEffect(() => {
    const id = setInterval(() => {
      setActiveIdx((prev) => (prev + 1) % HOME_PROJECTS.length);
    }, CYCLE_MS);
    return () => clearInterval(id);
  }, []);

  const project = HOME_PROJECTS[activeIdx];

  return (
    <>
      {/* ═══════════════════════════════════════════════════════════════════
          DESKTOP / LAPTOP  (lg and above) — UNCHANGED
      ═══════════════════════════════════════════════════════════════════ */}
      <div
        className="hidden lg:block w-full"
        data-name="HOME 1"
        style={isScaled ? { height: CANVAS_HEIGHT * desktopScale, overflow: "hidden" } : undefined}
      >
        <div
          ref={desktopMotionRef}
          className="relative"
          data-name="HOME 1 CANVAS"
          style={
            isScaled
              ? {
                  width: CANVAS_WIDTH,
                  height: CANVAS_HEIGHT,
                  transform: `scale(${desktopScale})`,
                  transformOrigin: "top left",
                }
              : { width: "100%", height: CANVAS_HEIGHT }
          }
        >
          <EntireWebsite />
          <FeatureWhySie />
          <Component2 project={project} />
          <ServicesSection />
          <FeatureWhySie1 project={project} />
          <Component3 project={project} />
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          MOBILE / TABLET  (below lg)
          Order:
          1. MobileTopImages  — two desktop-style images, flush to top (top: 0)
          2. MobileHeaderStrip — logo/nav header
          3. MobileImageCollage — tagline text first, then 3-photo strip
          4. MobileWhySIE
          5. MobileProjectHero
          6. MobileServicesSection
          7. MobileLandscapePhoto
          8. MobileFooter
      ═══════════════════════════════════════════════════════════════════ */}
      <div
        ref={mobileMotionRef}
        className="lg:hidden flex flex-col w-full min-h-screen overflow-x-hidden"
        data-name="HOME 1 MOBILE"
      >
        {/* 1. Two top-right desktop images — shown at very top, top: 0 */}
        <MobileHeroTop />

        {/* 3. Tagline text + 3-image collage (text first, images below) */}
        <MobileImageCollage />

        {/* 4. Why SIE / philosophy */}
        <MobileWhySIE />

        {/* 5. Project hero panel */}
        <MobileProjectHero project={project} />

        {/* 6. Services */}
        <MobileServicesSection />

        {/* 7. Landscape photo */}
        <MobileLandscapePhoto project={project} />

        {/* 8. Footer */}
        <MobileFooter project={project} />
      </div>
    </>
  );
}